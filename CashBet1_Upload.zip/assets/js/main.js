
function switchLang(lang) {
    document.querySelectorAll('[data-lang]').forEach(el => {
        el.style.display = el.dataset.lang === lang ? 'block' : 'none';
    });
}
